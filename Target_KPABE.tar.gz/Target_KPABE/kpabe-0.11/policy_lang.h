/*
	Include common.h before including this file.
*/

char* parse_policy_lang( char* s );
void  parse_attribute( GSList** l, char* a );
